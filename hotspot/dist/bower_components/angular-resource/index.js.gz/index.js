require('./angular-resource');
module.exports = 'ngResource';
